﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuessTheNumGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int guessNum;
            int rndNum;
            Random rnd = new Random();
            int count = 0;
            int countLeft = 3;
            string ask;

            rndNum = rnd.Next(1, 6);
            Console.WriteLine("=============WELCOME TO THE GUESS THE NUMBER GAME=============");
            Console.WriteLine("Note that you only have 4 chances to play: ");
            Console.WriteLine("");
            Console.WriteLine("Would you like to play the game (Yes / No): ");
            ask = Console.ReadLine();

            if (!Ask_user(ask))
            {
                Console.WriteLine("Thank you for the visit press enter to exit!!!");
            }
            else
            {
                while (count != 4)
                {
                    Console.WriteLine("Guess the Number From (1 - 6): ");
                    guessNum = Convert.ToInt32(Console.ReadLine());

                    if (guessNum < 1 || guessNum > 6)
                    {
                        Console.WriteLine("The number can not be greater than 6 0r Less than 1... Please re enter:");
                        guessNum = Convert.ToInt32(Console.ReadLine());
                    }

                    if (guessNum == rndNum)
                    {
                        Console.WriteLine("You got it correct. You Won!!!");

                        break;
                    }
                    else
                    {
                        Console.WriteLine("You got it wrong try again with " + countLeft-- + " chances left.");
                    }

                    if (countLeft < 0)
                    {
                        Console.WriteLine("You lost the game!!! Play again ");
                        Console.WriteLine("The number you looking for is: " + rndNum);

                    }

                    count++;
                }
            }

        }

        public static bool Ask_user(string answer)
        {
            if (answer.ToLower() == "yes")
            {
                return true;
            }
            else { return false; }
        }
    }
}
